/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.rbm.servicios.sms.procesadores;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.MDC;


/**
 *
 * @author carlos-itac
 */
public class ProcesadorMDC implements Processor{

    public void process(Exchange exchng) throws Exception {
        MDC.put("app.name", exchng.getContext().resolvePropertyPlaceholders("{{nombre.log}}"));
    }
    
}
